import cmath
# 1
# a = [1, 1, 2, 3, 5, 8, 10, 12, 34, 38, 40, 41, 46, 50, 55, 89]
# for num in a:
#     if num < 15:
#         print(num)
# #2
# number = float(input("введите число: "))
# if number > 0:
#     print("число положительное")
# elif number < 0:
#     print("число отрицвтельное")
# else:
#     print("ваше число - ноль")
#3
# def add(x, y):
#     return x + y
# def subtract(x,y):
#     return x-y    
# def multyplay(x,y):
#     return x*y
# def divide(x, y):
#     if y == 0:
#         return "Ошибка! Деление на ноль."
#     return x / y
# print("Выберите операцию:")
# print("1. Сложение")
# print("2. Вычитание")
# print("3. Умножение")
# print("4. Деление")
# while True:
#     choice = input("Введите выбор (1/2/3/4): ")

#     if choice in ['1', '2', '3', '4']:
#         num1 = float(input("Введите первое число: "))
#         num2 = float(input("Введите второе число: "))

#         if choice == '1':
#             print(f"{num1} + {num2} = {add(num1, num2)}")
#         elif choice == '2':
#             print(f"{num1} - {num2} = {subtract(num1, num2)}")
#         elif choice == '3':
#             print(f"{num1} * {num2} = {multiply(num1, num2)}")
#         elif choice == '4':
#             print(f"{num1} / {num2} = {divide(num1, num2)}")
#     else:
#         print("Неверный ввод")

#     # Спрашиваем, хочет ли пользователь выполнить еще одно вычисление
#     next_calculation = input("Хотите выполнить еще одно вычисление? (да/нет): ")
#     if next_calculation.lower() != 'да':
#         break
#4
# Обратный отсчет от 10 до 1
# for i in range(10, 0, -1):
#     print(i)
#5

# Ввод коэффициентов
# a = float(input("Введите коэффициент a (a ≠ 0): "))
# b = float(input("Введите коэффициент b: "))
# c = float(input("Введите коэффициент c: "))

# # Проверка, что a не равно 0
# if a == 0:
#     print("Коэффициент a не должен быть равен нулю.")
# else:
#     # Вычисление дискриминанта
#     D = b**2 - 4*a*c
#     print(f"Дискриминант D = {D}")

#     # Нахождение корней в зависимости от значения дискриминанта
#     if D > 0:
#         x1 = (-b + cmath.sqrt(D)) / (2 * a)
#         x2 = (-b - cmath.sqrt(D)) / (2 * a)
#         print(f"Уравнение имеет два различных корня: x1 = {x1}, x2 = {x2}")
#     elif D == 0:
#         x = -b / (2 * a)
#         print(f"Уравнение имеет один корень: x = {x}")
#     else:
#         real_part = -b / (2 * a)
#         imaginary_part = cmath.sqrt(-D) / (2 * a)
#         print(f"Уравнение имеет два комплексных корня: x1 = {real_part} + {imaginary_part}j, x2 = {real_part} - {imaginary_part}j")
